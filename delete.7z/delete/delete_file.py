import shutil
import os
import pandas as pd

data = pd.read_csv("/home/akshat/Downloads/process_queue (16).csv", sep=';', header=0)

for file in tuple(data['file_name']):
	os.remove('files/'+file)